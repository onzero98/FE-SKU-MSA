import { useEffect, useRef } from 'react';

function Part1() {
  
  return (
    <section id="Part1">
      <div className='title'> 원숭이도 주식투자가 가능하다 </div>
      <div className='scroll-ui-wrap'>
        <div className='txt'>scroll down</div>
      </div>
    </section>
  )
}

export default Part1;
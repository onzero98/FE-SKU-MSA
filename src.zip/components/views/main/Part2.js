import { useEffect, useRef } from 'react';

function Part2() {

  return (
    <section id="Part2">
      <div className='title' style={{color:'white'}}> 서브페이지 </div>
    </section>
  )
}

export default Part2;
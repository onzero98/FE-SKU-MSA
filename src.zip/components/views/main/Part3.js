import { useEffect, useRef } from 'react';

function Part3() {

  return (
    <section id="Part3">
      <div> 3 </div>
    </section>
  )
}

export default Part3;
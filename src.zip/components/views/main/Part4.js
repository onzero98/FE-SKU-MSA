import { useEffect, useRef } from 'react';

function Part4() {

  return (
    <section id="Part4">
      <div> 4 </div>
    </section>
  )
}

export default Part4;
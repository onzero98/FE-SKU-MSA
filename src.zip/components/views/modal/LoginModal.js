import React, { useState, useEffect } from "react";
import axios from "axios";

function LoginModal(props) {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = (event) => {
    event.preventDefault();

    setIsLoading(true);

    axios
      .post("http://localhost:8080/auth/signIn", {
        username: username,
        password: password,
      })
      .then((res) => {
        console.log(res);
        if (res.data) {
          sessionStorage.setItem("jwt-token", res.data.accessToken);
          props.onClose();
        } else {
          setError("잘못된 사용자 이름 또는 암호입니다.");
        }
      })
      .catch((error) => {
        console.error("Error:", error);
      })
      .finally(() => {
        setIsLoading(false);
      });
  };

  return (
    <>
      <div className="modal-background" onClick={props.onClose} />
      <div className="modal">
        <form onSubmit={handleSubmit}>
          <h2>로그인</h2>
          <div className="form-group">
            <label htmlFor="username">사용자 이름</label>
            <input
              type="text"
              id="username"
              value={username}
              onChange={(event) => setUsername(event.target.value)}
            />
          </div>
          <div className="form-group">
            <label htmlFor="password">암호</label>
            <input
              type="password"
              id="password"
              value={password}
              onChange={(event) => setPassword(event.target.value)}
            />
          </div>
          {error && <div className="error">{error}</div>}
          <button type="submit" disabled={isLoading}>
            {isLoading ? "처리 중..." : "로그인"}
          </button>
        </form>
      </div>
    </>
  );
}

export default LoginModal;
